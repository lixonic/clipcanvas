"""ClipCanvas: a small, local video creator for Ubuntu."""

__version__ = "0.11.5"
