"""Offline FFmpeg media operations. All public functions are worker-safe.

The render writes a temporary video beside its destination and atomically replaces
the destination only after success. It never rewrites source media.
"""

from __future__ import annotations

import array
from collections import OrderedDict
import copy
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time

from .model import adapt_frame_rate, clip_duration, media_items, project_duration, timeline, validate_project, is_card, is_image, is_still
from . import watermark
from . import audio_effects, transitions, color_grading


class RenderError(RuntimeError):
    pass


class RenderCancelled(RenderError):
    pass


@lru_cache(maxsize=2)
def _tool(name):
    """Resolve a working binary without changing the application's environment."""
    candidates = []
    override = os.environ.get("CLIPCANVAS_" + name.upper())
    if override:
        candidates.append((override, None))
    native = Path("/usr/bin") / name
    if native.is_file():
        candidates.append((str(native), None))
    found = shutil.which(name)
    if found:
        candidates.append((found, None))
    if name == "ffprobe":
        found = shutil.which("ffmpeg.ffprobe")
        if found:
            candidates.append((found, None))
    # The installed FFmpeg content snap also works without launching snap-confine.
    snap_root = Path("/snap/ffmpeg-2404/current")
    snap_binary = snap_root / "usr/bin" / name
    if snap_binary.is_file():
        env = os.environ.copy()
        env["LD_LIBRARY_PATH"] = str(snap_root / "usr/lib/x86_64-linux-gnu")
        candidates.append((str(snap_binary), env))
    for binary, env in candidates:
        try:
            check = subprocess.run([binary, "-version"], stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, env=env, timeout=5)
            if check.returncode == 0:
                return binary, env
        except (OSError, subprocess.TimeoutExpired):
            continue
    raise RenderError("FFmpeg is not available. Install the Ubuntu ‘ffmpeg’ package, then reopen ClipCanvas.")


def _fraction(value):
    try:
        top, bottom = str(value).split("/")
        return float(top) / float(bottom)
    except (ValueError, ZeroDivisionError):
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0


@lru_cache(maxsize=256)
def _probe_cached(path, size, mtime):
    binary, env = _tool("ffprobe")
    try:
        result = subprocess.run([binary, "-v", "error", "-show_format", "-show_streams",
                                 "-of", "json", path], capture_output=True, text=True,
                                env=env, timeout=30)
    except subprocess.TimeoutExpired as error:
        raise RenderError(f"Reading this file took too long: {Path(path).name}") from error
    if result.returncode:
        raise RenderError(f"Cannot read {Path(path).name}. It may be damaged or unsupported.\n{result.stderr[-600:].strip()}")
    try:
        data = json.loads(result.stdout)
        streams = data.get("streams", [])
        videos = [s for s in streams if s.get("codec_type") == "video"
                  and not s.get("disposition", {}).get("attached_pic", 0)]
        audios = [s for s in streams if s.get("codec_type") == "audio"]
        durations = []
        for value in [data.get("format", {}).get("duration")] + [s.get("duration") for s in streams]:
            try:
                candidate = float(value)
                if math.isfinite(candidate) and candidate > 0:
                    durations.append(candidate)
            except (ValueError, TypeError):
                pass
        if not durations or not (videos or audios):
            raise ValueError("No playable media duration")
        video = videos[0] if videos else {}
        width, height = int(video.get("width", 0)), int(video.get("height", 0))
        rotation = video.get("tags", {}).get("rotate", 0)
        for side in video.get("side_data_list", []):
            if "rotation" in side:
                rotation = side["rotation"]
        if abs(float(rotation)) % 180 > 45:
            width, height = height, width
        sar = _fraction(str(video.get("sample_aspect_ratio", "1:1")).replace(":", "/")) or 1
        return {"duration": max(durations), "width": width, "height": height,
                "has_audio": bool(audios), "has_video": bool(videos),
                "fps": _fraction(video.get("avg_frame_rate", "0/1")) or _fraction(video.get("r_frame_rate", "0/1")),
                "video_index": video.get("index", 0),
                "color_range": video.get("color_range", "unknown"),
                "audio_index": audios[0].get("index", 0) if audios else None,
                "audio_sample_rate": int(audios[0].get("sample_rate", 48000)) if audios else 0,
                "audio_channels": int(audios[0].get("channels", 1)) if audios else 0,
                "format_name": data.get('format', {}).get('format_name', ''),
                "decoded_sample_aspect_ratio": 1/sar if abs(float(rotation)) % 180 > 45 else sar,
                "sample_aspect_ratio": sar}
    except (ValueError, TypeError, KeyError) as error:
        raise RenderError(f"Cannot read the duration of {Path(path).name}. Use a video or audio file with a known duration.") from error


def probe(path):
    path = Path(path).expanduser().resolve()
    try:
        stat = path.stat()
    except OSError as error:
        raise RenderError(f"Cannot open media: {path}") from error
    return dict(_probe_cached(str(path), stat.st_size, stat.st_mtime_ns))


def image_picture(path):
    """Decode supported local still formats, respecting camera orientation."""
    import gi
    gi.require_version('GdkPixbuf', '2.0')
    from gi.repository import GdkPixbuf
    try:
        return GdkPixbuf.Pixbuf.new_from_file(str(path)).apply_embedded_orientation()
    except Exception as error:
        raise RenderError(f'Cannot read image {Path(path).name}. Choose a supported PNG, JPEG, WebP, BMP, TIFF or SVG image.') from error


def probe_image(path):
    picture = image_picture(path)
    return {'width': picture.get_width(), 'height': picture.get_height(),
            'has_video': False, 'has_audio': False, 'fps': 0}


def _image_source(path, target):
    # Rasterize SVGs and normalize EXIF/alpha once per composition, so every
    # decoder sees the same oriented picture on a black canvas.
    picture = image_picture(path)
    from gi.repository import GdkPixbuf
    if picture.get_has_alpha():
        picture = picture.composite_color_simple(picture.get_width(), picture.get_height(),
            GdkPixbuf.InterpType.NEAREST, 255, max(picture.get_width(), picture.get_height()), 0, 0)
    # These disposable frames need lossless pixels, not expensive compression.
    picture.savev(str(target), 'png', ['compression'], ['1'])
    return str(target)


def _fmt(number):
    return format(float(number), ".8f").rstrip("0").rstrip(".") or "0"


def _tempo(speed):
    """Pitch-preserving tempo changes, including FFmpeg versions limited to 2x."""
    remaining = float(speed)
    if abs(remaining - 1.0) < 1e-9:
        return []
    filters = []
    while remaining < .5:
        filters.append("atempo=0.5")
        remaining /= .5
    while remaining > 2:
        filters.append("atempo=2")
        remaining /= 2
    filters.append(f"atempo={_fmt(remaining)}")
    return filters


def _audio_fades(item, audible_length):
    """User fades and the independent transition envelope copied on extraction."""
    filters = []
    for prefix in ("", "transition_"):
        fade_in = min(float(item.get(prefix + "fade_in", 0)), audible_length)
        fade_out = min(float(item.get(prefix + "fade_out", 0)), audible_length)
        if fade_in > 0:
            filters.append(f"afade=t=in:st=0:d={_fmt(fade_in)}")
        if fade_out > 0:
            filters.append(f"afade=t=out:st={_fmt(audible_length-fade_out)}:d={_fmt(fade_out)}")
    return filters


def _processed_audio(item, length, audible_length=None, with_effects=True):
    """The same trim/tempo/effect/volume/fade chain for render and audition.

    Echo is bounded by the item's trimmed duration. It does not extend the
    timeline or leak into the following clip. Delay is measured after speed.
    """
    filters=_tempo(item.get('speed',1))
    filters.extend(['apad',f'atrim=duration={_fmt(length)}'])
    if with_effects:filters.extend(audio_effects.filters(item))
    filters.extend([f'atrim=duration={_fmt(length)}',f'volume={_fmt(item.get("volume",1))}'])
    filters.extend(_audio_fades(item,length if audible_length is None else audible_length))
    return filters


def _audio_input(item, metadata):
    """Return input arguments and a source trim that tolerates WAV headers.

    Some generated PCM WAVs have a stale byte-rate field. Demuxer seeking then
    lands at the wrong sample (or beyond EOF). Decode from zero and trim using
    sample counts for WAV, without rewriting the user's source.
    """
    if metadata.get('format_name') == 'wav':
        rate = metadata['audio_sample_rate']
        trim = f"atrim=start_sample={round(item.get('in',0)*rate)}:end_sample={round(item['out']*rate)},"
        return ['-threads','1','-t',_fmt(item['out']),'-i',item['path']], trim
    return ['-threads','1','-ss',_fmt(item.get('in',0)),
            '-t',_fmt(item['out']-item.get('in',0)),'-i',item['path']], ''


def _continuous_audio(tracks):
    """Render untouched adjacent cuts through one continuous audio processor.

    Splitting is an editing operation: it must not reset tempo/echo/compressor
    history or cut off an echo at the new middle boundary. Only join pieces
    whose source, placement and processing still match; the saved pieces stay
    independent. Gaps, moves, edits and explicit fades keep separate inputs.
    """
    ignored={'id','source_clip_id','in','out','start','fade_in','fade_out',
             'transition_fade_in','transition_fade_out'}
    result=[];tails={}
    for item in sorted(tracks,key=lambda track:track.get('start',0)):
        lane=item.get('lane_id',item['id'])
        left=tails.get(lane)
        same=left is not None and {k:v for k,v in left.items() if k not in ignored}=={k:v for k,v in item.items() if k not in ignored}
        if (same and abs(left['out']-item.get('in',0))<1e-8
                and abs(left['start']+clip_duration(left)-item['start'])<1e-8
                and not any(left.get(k,0) for k in ('fade_out','transition_fade_out'))
                and not any(item.get(k,0) for k in ('fade_in','transition_fade_in'))):
            left['out']=item['out']
            for key in ('fade_out','transition_fade_out'):left[key]=item.get(key,0)
        else:
            merged=copy.deepcopy(item);result.append(merged);tails[lane]=merged
    return result


def _stop(process, *, immediate=False):
    if process.poll() is not None:
        return
    # A discarded live pipe has no file trailer to preserve. FFmpeg may block
    # flushing that pipe after SIGTERM while its paused consumer has stopped
    # reading. Kill/reap it directly so rapid seeks do not leave stale decoders.
    if immediate:
        process.kill()
        process.wait()
        return
    process.terminate()
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def _execute(arguments, seconds, progress, cancel, log_path, *, background=False):
    binary, env = _tool("ffmpeg")
    if cancel is not None and cancel.is_set():
        raise RenderCancelled("Export cancelled.")
    command = [binary] + arguments
    nice = shutil.which('nice') if background else None
    if nice:command = [nice, '-n', '10'] + command
    with open(log_path, "wb") as log:
        process = subprocess.Popen(command, stdout=subprocess.PIPE,
                                   stderr=log, stdin=subprocess.DEVNULL, env=env)
        # Windows selectors cannot watch subprocess pipes. A reader thread also
        # leaves the main worker free to cancel when FFmpeg emits no progress.
        messages = queue.SimpleQueue()
        def read_progress():
            try:
                for line in iter(process.stdout.readline, b""):
                    messages.put(line.decode("utf-8", "replace").strip())
            finally:
                messages.put(None)
        reader = threading.Thread(target=read_progress, daemon=True)
        reader.start()
        try:
            while True:
                if cancel is not None and cancel.is_set():
                    _stop(process)
                    raise RenderCancelled("Export cancelled.")
                try:
                    line = messages.get(timeout=.15)
                except queue.Empty:
                    continue
                if line is None:
                    break
                if line.startswith(("out_time_us=", "out_time_ms=")):
                    try:
                        elapsed = float(line.split("=", 1)[1]) / 1000000
                    except ValueError:
                        continue
                    if progress:
                        progress(min(0.995, max(0.0, elapsed / max(seconds, 0.001))), "Rendering your video…")
            process.wait()
            if process.returncode:
                log.flush()
                detail = Path(log_path).read_text(errors="replace")[-2500:].strip()
                raise RenderError("The video could not be rendered. Check that the media files are readable and the destination has free space.\n\n" + detail)
        except BaseException:
            _stop(process)
            raise
        finally:
            _stop(process)
            reader.join(timeout=3)
            process.stdout.close()


MAX_CAPTION_CACHE_BYTES = 32 * 1024 * 1024
MAX_CAPTION_CACHE_ENTRIES = 512
_CAPTION_CACHE_LOCK = threading.Lock()
_CAPTION_CACHE_DIR = None
_CAPTION_CACHE = OrderedDict()
_CAPTION_CACHE_BYTES = 0


def _caption_cache_key(project, width, height, left, top, sw, sh, animated, soft, state):
    payload = (
        int(project.get('width', width)), int(project.get('height', height)),
        int(width), int(height), int(left), int(top), int(sw), int(sh),
        bool(animated), bool(soft), project.get('caption_style', {}), state,
    )
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode('utf-8')).hexdigest()


def _caption_cache_lease(cache_key, target):
    with _CAPTION_CACHE_LOCK:
        entry = _CAPTION_CACHE.get(cache_key)
        if entry is None:
            return False
        source, size = entry
        if not source.is_file():
            _CAPTION_CACHE.pop(cache_key, None)
            return False
        _CAPTION_CACHE.move_to_end(cache_key)
        try:
            try:
                os.link(source, target)
            except OSError:
                shutil.copyfile(source, target)
            return True
        except OSError:
            return False


def _caption_cache_store(cache_key, source):
    global _CAPTION_CACHE_DIR, _CAPTION_CACHE_BYTES
    try:
        size = source.stat().st_size
    except OSError:
        return
    if size > MAX_CAPTION_CACHE_BYTES // 4:
        return
    with _CAPTION_CACHE_LOCK:
        if cache_key in _CAPTION_CACHE:
            _CAPTION_CACHE.move_to_end(cache_key)
            return
        if _CAPTION_CACHE_DIR is None:
            _CAPTION_CACHE_DIR = tempfile.TemporaryDirectory(prefix='clipcanvas-caption-cache-')
        cached_path = Path(_CAPTION_CACHE_DIR.name) / f'{cache_key}.png'
        try:
            if not cached_path.exists():
                try:
                    os.link(source, cached_path)
                except OSError:
                    shutil.copyfile(source, cached_path)
        except OSError:
            return
        _CAPTION_CACHE[cache_key] = (cached_path, size)
        _CAPTION_CACHE_BYTES += size
        while len(_CAPTION_CACHE) > MAX_CAPTION_CACHE_ENTRIES or _CAPTION_CACHE_BYTES > MAX_CAPTION_CACHE_BYTES:
            _, (old_path, old_size) = _CAPTION_CACHE.popitem(last=False)
            _CAPTION_CACHE_BYTES = max(0, _CAPTION_CACHE_BYTES - old_size)
            old_path.unlink(missing_ok=True)


def _word_stream(project, item, scratch, width, height, prefix, soften=False, cancel=None,
                 window_start=None, window_end=None):
    """One decoder, one bounded sprite per word state, never a canvas PNG movie."""
    from . import animations, visuals
    import cairo
    item_start = float(item['start'])
    item_end = float(item['end'])
    length = item_end - item_start
    steps = max(1, animations.text_steps(item))
    step_length = length / steps
    ws = item_start if window_start is None else max(item_start, float(window_start))
    we = item_end if window_end is None else min(item_end, float(window_end))
    sequence = ['ffconcat version 1.0']
    plain = dict(item, rotation=0, opacity=1)
    last_path = None
    for step in range(steps):
        if cancel is not None and cancel.is_set():
            raise RenderCancelled('Export cancelled.')
        seg_start = item_start + step * step_length
        seg_end = item_start + (step + 1) * step_length
        if seg_end <= ws + 1e-9 or seg_start >= we - 1e-9:
            continue
        clipped_start = max(ws, seg_start)
        clipped_end = min(we, seg_end)
        if clipped_end <= clipped_start + 1e-9:
            continue
        sprite = dict(plain, _text_effect=animations.normalise(item.get('animation'))['text_effect'], _text_step=step)
        path = Path(scratch)/f'{prefix}-{step}.png'
        visuals.rasterize(project, sprite, path, (width, height))
        if soften:
            visuals.soften(cairo.ImageSurface.create_from_png(str(path))).write_to_png(str(path))
        sequence += [f"file '{path.as_posix()}'", 'option framerate 1000', f'duration {_fmt(clipped_end - clipped_start)}']
        last_path = path
    if last_path is None:
        step = min(steps - 1, max(0, int((ws - item_start) / max(1e-9, step_length))))
        sprite = dict(plain, _text_effect=animations.normalise(item.get('animation'))['text_effect'], _text_step=step)
        last_path = Path(scratch)/f'{prefix}-{step}.png'
        visuals.rasterize(project, sprite, last_path, (width, height))
        if soften:
            visuals.soften(cairo.ImageSurface.create_from_png(str(last_path))).write_to_png(str(last_path))
        sequence += [f"file '{last_path.as_posix()}'", 'option framerate 1000', f'duration {_fmt(max(0.01, we - ws))}']
    sequence += [f"file '{last_path.as_posix()}'", 'option framerate 1000']
    target = Path(scratch)/f'{prefix}.ffconcat'
    target.write_text('\n'.join(sequence)+'\n', encoding='utf-8')
    return target


def _caption_lanes(project):
    """Keep the decoder count proportional to simultaneous captions, not cues."""
    lanes = []
    for cue in sorted(project.get('captions', []), key=lambda item: (item['start'], item['end'])):
        lane = next((items for items in lanes if items[-1]['end'] <= cue['start']), None)
        if lane is None:
            lane = []
            lanes.append(lane)
        lane.append(cue)
    return lanes


def _cue_expressions(project, variable='t'):
    from . import animations, visuals
    result = {key: base for key, base in (('dx', '0'), ('dy', '0'), ('opacity', '1'), ('scale', '1'), ('wipe', '1'), ('blur', '0'), ('mask', '1'))}
    for cue in reversed(project.get('captions', [])):
        item = visuals.caption_item(project, cue['text'], cue)
        values = animations.expressions(item, variable)
        if values['wipe'] != '1':
            values['mask'] = _wipe_mask(item, values['wipe'])
        for key, expression in values.items():
            if expression != result[key] or expression not in ('0', '1'):
                result[key] = f'if(gte({variable},{_fmt(cue["start"])})*lt({variable},{_fmt(cue["end"])}),{expression},{result[key]})'
    return result


def _element_motion(filters, source, output, item, width, height, values=None, blurred=None, caption=False,
                    fps=30, length=None, scratch=None, cues=None, project=None, cancel=None, stream_start=None):
    """Animate a sprite with global-time expressions; preserve source resolution."""
    from . import animations
    values = values or animations.expressions(item)
    placement = animations.placement_expressions(item)
    from . import element_render
    if stream_start is not None:
        current = element_render.append(filters,source,output+'native',item,width,height,fps,length,scratch,
                                        blurred,cues,project,cancel,stream_start=stream_start)
    else:
        current = element_render.append(filters,source,output+'native',item,width,height,fps,length,scratch,
                                        blurred,cues,project,cancel)
    parts = [f'[{current}]format=rgba']
    motion_scale = values['scale']
    ratio_w, ratio_h = '1', '1'
    if item.get('_match_to'):
        ratio_w = f'({placement["width"]})/{_fmt(item["width"])}'
        ratio_h = f'({placement["height"]})/{_fmt(item["height"])}'
    if motion_scale != '1' or ratio_w != '1' or ratio_h != '1':
        parts.append(f"scale=w='max(2,round(iw*({motion_scale})*({ratio_w})))':h='max(2,round(ih*({motion_scale})*({ratio_h})))':eval=frame")
    if not caption and (float(item.get('rotation', 0)) or item.get('_match_to') and float(item['_match_to'].get('rotation', 0)) != float(item.get('rotation', 0))):
        angle = f'({placement["rotation"]})*PI/180'
        parts.append(f"rotate=a='{angle}':ow='ceil(hypot(iw,ih))':oh='ceil(hypot(iw,ih))':c=0x00000000")
    filters.append(','.join(parts)+f'[{output}]')
    x = f'{_fmt(width)}*(({placement["x"]})+({values["dx"]}))-overlay_w/2'
    y = f'{_fmt(height)}*(({placement["y"]})+({values["dy"]}))-overlay_h/2'
    return f"x='{x}':y='{y}'"


def _expression_time(expression, variable):
    import re
    return re.sub(r'\bt\b', variable, expression)


def _wipe_mask(item, progress):
    from . import animations
    direction = animations.normalise(item.get('animation'))['direction']
    axis, extent = ('X', 'W') if direction in ('left', 'right') else ('Y', 'H')
    return (f'gte({axis},{extent}*(1-({progress})))' if direction in ('left', 'up')
            else f'lt({axis},{extent}*({progress}))')


def _animated_visual(project, item, number, args, filters, width, height, fps, length, scratch, cancel=None,
                     stream_start=None, stream_end=None):
    from . import animations, visuals
    import cairo
    item_start = float(item['start'])
    item_end = item_start + float(length)
    eff_start = item_start if stream_start is None else max(item_start, float(stream_start))
    eff_end = item_end if stream_end is None else min(item_end, float(stream_end))
    if eff_end <= eff_start:
        eff_start, eff_end = item_start, item_end
    eff_length = max(1 / fps, eff_end - eff_start)
    animation = animations.normalise(item.get('animation'))
    blur = animation['enter'] == 'blur' or animation['exit'] == 'blur'
    source = f'motionbase{number}'
    plain = dict(item, rotation=0, opacity=1)
    inputs = []
    if item['kind'] in ('text', 'image'):
        for soft in ((False, True) if blur else (False,)):
            index = args.count('-i')
            prefix = f'layer-{number}'+('-soft' if soft else '')
            if item['kind'] == 'text' and animation['text_effect'] != 'none':
                path = _word_stream(project, plain, scratch, width, height, prefix, soft, cancel,
                                    window_start=eff_start if stream_start is not None else None,
                                    window_end=eff_end if stream_end is not None else None)
                args += ['-threads', '1', '-f', 'concat', '-safe', '0', '-i', str(path)]
                preparation = f'fps={_fmt(fps)},trim=duration={_fmt(eff_length)}'
            else:
                path = Path(scratch)/f'{prefix}.png'
                visuals.rasterize(project, plain, path, (width, height))
                if soft:
                    visuals.soften(cairo.ImageSurface.create_from_png(str(path))).write_to_png(str(path))
                args += ['-threads', '1', '-loop', '1', '-framerate', _fmt(fps), '-t', _fmt(eff_length), '-i', str(path)]
                preparation = 'null'
            label = source+('soft' if soft else '')
            filters.append(f'[{index}:v]{preparation},format=rgba,settb=AVTB,setpts=PTS-STARTPTS+{_fmt(eff_start)}/TB[{label}]')
            inputs.append(label)
    else:
        index = args.count('-i')
        metadata = probe(item['path'])
        if not metadata['has_video']:
            raise RenderError(f"{Path(item['path']).name} has no video to use as an overlay.")
        speed = float(item.get('speed', 1))
        seek_offset = max(0.0, eff_start - item_start)
        if seek_offset <= 1.0:
            eff_start = item_start
            eff_length = max(1 / fps, eff_end - eff_start)
            seek_offset = 0.0
        source_in = float(item.get('in', 0)) + seek_offset * speed
        if source_in < metadata['duration'] - 0.05:
            available = min(metadata['duration'] - source_in, eff_length * speed)
        else:
            source_in = max(0.0, metadata['duration'] - 0.1)
            available = min(metadata['duration'] - source_in, 0.1)
        args += ['-threads', '1', '-ss', _fmt(source_in), '-t', _fmt(available), '-i', item['path']]
        bw, bh = max(1, round(width*item['width'])), max(1, round(height*item['height']))
        fit = 'decrease' if item.get('fit', 'fit') == 'fit' else 'increase'
        framing = f'scale=trunc(iw*sar/2)*2:ih,setsar=1,format=rgba,scale={bw}:{bh}:force_original_aspect_ratio={fit}'
        framing += (f',pad={bw}:{bh}:(ow-iw)/2:(oh-ih)/2:color=0x00000000' if fit == 'decrease' else f',crop={bw}:{bh}:(iw-ow)/2:(ih-oh)/2')
        filters.append(f'[{index}:{metadata["video_index"]}]{framing},setpts=(PTS-STARTPTS)/{_fmt(speed)},fps={_fmt(fps)},tpad=stop_mode=clone:stop_duration={_fmt(eff_length)},trim=duration={_fmt(eff_length)},settb=AVTB,setpts=PTS-STARTPTS+{_fmt(eff_start)}/TB[{source}]')
        if blur:
            sharp = source+'sharp'
            filters.append(f'[{source}]split=2[{sharp}][{source}blurinput]')
            filters.append(f'[{source}blurinput]gblur=sigma=6:steps=2[{source}soft]')
            inputs = [sharp, source+'soft']
        else:
            inputs = [source]
    placement = _element_motion(filters, inputs[0], f'visual{number}', item, width, height,
                                blurred=inputs[1] if blur else None,fps=fps,length=eff_length,scratch=scratch,
                                project=project,cancel=cancel,
                                stream_start=eff_start if eff_start != item_start else None)
    return placement


def _caption_stream(project, scratch, width, height, total, cancel=None, prefix="captions", animated=False, soft=False,
                    window_start=0.0, window_end=None):
    """Make one variable-duration PNG stream for captions in [window_start, window_end].

    Only one decoder is used even for thousands of cues. PNG sprites share the
    caption box, are reused across windows via a bounded LRU cache, and follow
    list order for overlapping cues just as they do in the native preview.
    """
    from . import visuals, animations
    import cairo
    ws = max(0.0, float(window_start))
    we = float(total) if window_end is None else min(float(total), float(window_end))
    if we <= ws:
        return None
    cues = [c for c in project.get('captions', []) if c['start'] < we and c['end'] > ws]
    if not cues:
        return None
    item = visuals.caption_item(project, '')
    if animated: item.update(rotation=0, opacity=1)
    left, top, sw, sh = visuals.sprite_geometry(project, item, (width, height))
    events = {}
    active = set()
    for index, cue in enumerate(cues):
        c_start = max(0.0, float(cue['start']))
        c_end = min(float(total), float(cue['end']))
        if c_start <= ws:
            active.add(index)
        elif c_start < we:
            events.setdefault(c_start, []).append((index, True))
        if ws < c_end < we:
            events.setdefault(c_end, []).append((index, False))
        styled = visuals.caption_item(project, cue['text'], cue)
        if animations.normalise(styled.get('animation'))['text_effect'] != 'none':
            for boundary in animations.text_boundaries(styled):
                if ws < boundary < we:
                    events.setdefault(boundary, [])
    boundaries = sorted({ws, we} | set(events))
    cached = {}
    sequence = ['ffconcat version 1.0']
    last_path = None
    for begin, end in zip(boundaries, boundaries[1:]):
        if cancel is not None and cancel.is_set():
            raise RenderCancelled('Export cancelled.')
        if end <= begin:
            continue
        for index, entering in events.get(begin, []):
            if entering:
                active.add(index)
            else:
                active.discard(index)
        state = []
        sprites = []
        for index in sorted(active):
            cue = cues[index]
            sprite = visuals.caption_item(project, cue['text'], cue)
            effect = animations.normalise(sprite.get('animation'))['text_effect']
            step = animations.text_step(sprite, begin+1e-8)
            word_range = animations.text_word_range(sprite, step) if effect != 'none' else None
            sprite['_text_effect'] = effect
            sprite['_text_step'] = step
            if animated:
                sprite.update(rotation=0, opacity=1)
            sprites.append(sprite)
            state.append((cue['text'], effect, step, word_range,
                          cue.get('animation', project.get('caption_style', {}).get('animation'))))
        state_key = tuple(
            (text, effect, step, word_range, json.dumps(anim, sort_keys=True, default=str))
            for text, effect, step, word_range, anim in state
        )
        if state_key not in cached:
            path = Path(scratch)/f'{prefix}-{len(cached)}.png'
            global_key = _caption_cache_key(project, width, height, left, top, sw, sh, animated, soft, state_key)
            if not _caption_cache_lease(global_key, path):
                surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, sw, sh)
                cr = cairo.Context(surface)
                cr.translate(-left, -top)
                for sprite in sprites:
                    visuals._paint(cr, project, sprite, (0, 0, width, height))
                if soft:
                    surface = visuals.soften(surface)
                surface.write_to_png(str(path))
                _caption_cache_store(global_key, path)
            cached[state_key] = path
        last_path = cached[state_key]
        # The image demuxer's fine timebase retains sub-frame cue boundaries;
        # the main canvas frame rate decides which frame displays each cue.
        sequence += [f"file '{last_path.as_posix()}'", 'option framerate 1000', f'duration {_fmt(end-begin)}']
    sequence += [f"file '{last_path.as_posix()}'", 'option framerate 1000']
    sequence_path = Path(scratch)/f'{prefix}.ffconcat'
    sequence_path.write_text('\n'.join(sequence)+'\n', encoding='utf-8')
    return sequence_path, left, top


def _visual_graph(project, args, filters, video, width, height, fps, total, scratch, cancel=None,
                  window_start=0.0, window_end=None):
    """Append ordered transparent layers without interpreting user text as code."""
    windowed = window_start > 0 or window_end is not None
    ws = max(0.0, float(window_start))
    we = float(total) if window_end is None else min(float(total), float(window_end))
    layers = [item for item in project.get('layers', [])
              if item['start'] < we and item['end'] > ws and float(item.get('_suppress_until', 0)) < we]
    active_captions = [c for c in project.get('captions', []) if c['start'] < we and c['end'] > ws]
    if not layers and not active_captions:
        return video
    if scratch is None:
        raise RenderError('Visual rendering needs a temporary working folder.')
    from . import visuals, animations
    next_input = args.count('-i')
    aligned_ws = max(0.0, math.floor(ws * fps) / fps) if windowed else 0.0
    aligned_we = min(float(total), we + 2 / fps) if windowed else float(total)
    for number, item in enumerate(layers):
        if cancel is not None and cancel.is_set():
            raise RenderCancelled('Export cancelled.')
        start, end = max(0.0, float(item['start'])), min(total, float(item['end']))
        length = end-start
        if windowed:
            eff_start = aligned_ws if start < aligned_ws - 2 / fps else start
            eff_end = min(end, aligned_we)
            if eff_end <= eff_start:
                eff_start, eff_end = start, end
            eff_length = max(1 / fps, eff_end - eff_start)
        else:
            eff_start, eff_end, eff_length = start, end, length
        if animations.animated(item) or item.get('_match_from'):
            try:
                placement = _animated_visual(
                    project, item, number, args, filters, width, height, fps, length, scratch, cancel,
                    stream_start=eff_start if windowed else None,
                    stream_end=eff_end if windowed else None,
                )
            except RenderCancelled: raise
            except Exception as error:
                raise RenderError(f'Could not animate visual layer {number+1}: {error}') from error
        elif item['kind'] in ('text', 'image'):
            path = Path(scratch)/f'layer-{number}.png'
            try:
                x, y = visuals.rasterize(project, item, path, (width, height))
            except Exception as error:
                raise RenderError(f"Could not read or draw visual layer {number+1}: {error}") from error
            args += ['-threads', '1', '-loop', '1', '-framerate', _fmt(fps), '-t', _fmt(eff_length), '-i', str(path)]
            filters.append(f'[{next_input}:v]format=rgba,settb=AVTB,setpts=PTS-STARTPTS+{_fmt(eff_start)}/TB[visual{number}]')
            placement = f'x={x}:y={y}'
        else:
            metadata = probe(item['path'])
            if not metadata['has_video']:
                raise RenderError(f"{Path(item['path']).name} has no video to use as an overlay.")
            speed = float(item.get('speed', 1))
            seek_offset = max(0.0, eff_start - start)
            if seek_offset <= 1.0:
                eff_start = start
                eff_length = max(1 / fps, eff_end - eff_start)
                seek_offset = 0.0
            source_in = float(item.get('in', 0)) + seek_offset * speed
            if source_in < metadata['duration'] - 0.05:
                available = min(metadata['duration'] - source_in, eff_length * speed)
            else:
                source_in = max(0.0, metadata['duration'] - 0.1)
                available = min(metadata['duration'] - source_in, 0.1)
            args += ['-threads', '1', '-ss', _fmt(source_in), '-t', _fmt(available), '-i', item['path']]
            bw = max(1, round(width*item['width']));bh = max(1, round(height*item['height']))
            fit = 'decrease' if item.get('fit', 'fit') == 'fit' else 'increase'
            framing = f'scale=trunc(iw*sar/2)*2:ih,setsar=1,format=rgba,scale={bw}:{bh}:force_original_aspect_ratio={fit}'
            if fit == 'decrease':
                framing += f',pad={bw}:{bh}:(ow-iw)/2:(oh-ih)/2:color=0x00000000'
            else:
                framing += f',crop={bw}:{bh}:(iw-ow)/2:(ih-oh)/2'
            parts = [f'[{next_input}:{metadata["video_index"]}]{framing}',
                     f'setpts=(PTS-STARTPTS)/{_fmt(speed)}', f'fps={_fmt(fps)}',
                     f'tpad=stop_mode=clone:stop_duration={_fmt(eff_length)}', f'trim=duration={_fmt(eff_length)}']
            angle = math.radians(item.get('rotation', 0))
            if angle:
                a = _fmt(angle)
                parts.append(f'rotate={a}:ow=rotw({a}):oh=roth({a}):c=0x00000000')
            parts += [f'colorchannelmixer=aa={_fmt(item.get("opacity", 1))}', 'settb=AVTB',
                      f'setpts=PTS-STARTPTS+{_fmt(eff_start)}/TB']
            filters.append(','.join(parts)+f'[visual{number}]')
            placement = f'x={_fmt(width*item["x"])}-overlay_w/2:y={_fmt(height*item["y"])}-overlay_h/2'
        start = max(start, float(item.get('_suppress_until', 0)))
        label = f'composite{number}'
        filters.append(f"[{video}][visual{number}]overlay={placement}:eof_action=pass:repeatlast=0:format=auto:enable='gte(t,{_fmt(start)})*lt(t,{_fmt(end)})'[{label}]")
        video = label
        next_input = args.count('-i')
    if not active_captions:
        return video
    # Keep static ffconcat caption windows on exact integer milliseconds so
    # option framerate 1000 never rounds cue entry boundaries past a frame.
    cap_ws = (math.floor(aligned_ws * 1000) / 1000) if windowed else 0.0
    cap_we = aligned_we if windowed else float(total)
    pts_shift = f'+{_fmt(cap_ws)}/TB' if cap_ws > 0 else ''
    animated_captions = any(animations.animated(visuals.caption_item(project, cue['text'], cue)) for cue in active_captions)
    if animated_captions:
        anim_ws = aligned_ws if windowed else 0.0
        anim_pts_shift = f'+{_fmt(anim_ws)}/TB' if anim_ws > 0 else ''
        window_captions = dict(project, captions=active_captions)
        for lane_number, cues in enumerate(_caption_lanes(window_captions)):
            caption_project = dict(project, captions=cues)
            values = _cue_expressions(caption_project)
            inputs = []
            blur = values['blur'] != '0'
            for soft in ((False, True) if blur else (False,)):
                prefix = f'captions-{lane_number}'+('-soft' if soft else '')
                stream = _caption_stream(caption_project, scratch, width, height, total, cancel, prefix, True, soft,
                                         window_start=anim_ws, window_end=cap_we)
                if stream is None:
                    break
                sequence, _, _ = stream
                index = args.count('-i')
                args += ['-threads', '1', '-f', 'concat', '-safe', '0', '-i', str(sequence)]
                source = f'captionbase{lane_number}'+('soft' if soft else '')
                filters.append(f'[{index}:v]fps={_fmt(fps)},format=rgba,settb=AVTB,setpts=PTS-STARTPTS{anim_pts_shift}[{source}]')
                inputs.append(source)
            if not inputs:
                continue
            item = visuals.caption_item(project, '')
            placement = _element_motion(filters, inputs[0], f'captionmotion{lane_number}', item, width, height, values, inputs[1] if blur else None,
                                        fps=fps,length=max(1 / fps, cap_we - anim_ws),scratch=scratch,cues=cues,project=project,cancel=cancel,
                                        stream_start=anim_ws if anim_ws > 0 else None)
            label = f'captioned{lane_number}'
            filters.append(f'[{video}][captionmotion{lane_number}]overlay={placement}:eof_action=pass:repeatlast=0:format=auto[{label}]')
            video = label
        return video
    try:
        captions = _caption_stream(dict(project, captions=active_captions), scratch, width, height, total, cancel,
                                   window_start=cap_ws, window_end=cap_we)
    except RenderCancelled:
        raise
    except Exception as error:
        raise RenderError(f'Could not draw captions: {error}') from error
    if captions:
        sequence, x, y = captions
        args += ['-threads', '1', '-f', 'concat', '-safe', '0', '-i', str(sequence)]
        filters.append(f'[{next_input}:v]format=rgba,settb=AVTB,setpts=PTS-STARTPTS{pts_shift}[captionpicture]')
        filters.append(f'[{video}][captionpicture]overlay=x={x}:y={y}:eof_action=pass:repeatlast=0:format=auto[captioned]')
        video = 'captioned'
    return video


def preview_dimensions(project, max_edge=640):
    """0 means the full project canvas; never enlarge beyond that canvas."""
    if isinstance(max_edge, bool) or not isinstance(max_edge, (int, float)) or not math.isfinite(max_edge) or max_edge < 0:
        raise RenderError('Choose a valid preview resolution.')
    width, height = int(project['width']), int(project['height'])
    scale = min(1, max_edge/max(width, height)) if max_edge else 1
    return max(2, round(width*scale/2)*2), max(2, round(height*scale/2)*2)


def _bounded_clip_frame(clip, source_width, source_height, width, height):
    """Crop in source space before scaling a saved static picture transform.

    The former scale-then-crop path enlarged a 4K picture to 16K at 400% and
    retained those enormous frames for each timeline input. Only the source
    intersection that can appear inside the output is needed here. Every
    scaled/padded frame is therefore at most the output canvas dimensions.
    """
    zoom = clip.get('zoom', 1)
    target_w = max(2, round(width*zoom/2)*2)
    target_h = max(2, round(height*zoom/2)*2)
    fit = clip.get('fit', 'fill') == 'fit'
    factor = (min if fit else max)(target_w/source_width, target_h/source_height)
    divisible = math.floor if fit else math.ceil
    scaled_w = max(2, divisible(source_width*factor/2)*2)
    scaled_h = max(2, divisible(source_height*factor/2)*2)
    ax = clip.get('position_x', .5) if scaled_w > width else .5
    ay = clip.get('position_y', .5) if scaled_h > height else .5
    left = (width-scaled_w)*ax+clip.get('offset_x', 0)*width
    top = (height-scaled_h)*ay+clip.get('offset_y', 0)*height
    # Match the chroma-aligned placement of the YUV overlay/crop filters.
    left, top = math.floor(int(left)/2)*2, math.floor(int(top)/2)*2
    x0, y0 = max(0, left), max(0, top)
    x1, y1 = min(width, left+scaled_w), min(height, top+scaled_h)
    if x1 <= x0 or y1 <= y0:
        return f'scale={width}:{height},drawbox=color=black:t=fill:replace=1'
    sx0 = max(0, min(source_width-1, round((x0-left)*source_width/scaled_w)))
    sy0 = max(0, min(source_height-1, round((y0-top)*source_height/scaled_h)))
    sx1 = max(sx0+1, min(source_width, round((x1-left)*source_width/scaled_w)))
    sy1 = max(sy0+1, min(source_height, round((y1-top)*source_height/scaled_h)))
    return (f'crop={sx1-sx0}:{sy1-sy0}:{sx0}:{sy0}:exact=1,'
            f'scale={x1-x0}:{y1-y0},setsar=1,'
            f'pad={width}:{height}:{x0}:{y0}:black')


def _bounded_image_motion(clip, sw, sh, width, height, fps, seek, remaining):
    """Animate a source-space window using a fixed, two-canvas working image.

    A union of all motion windows is cropped from the original once. Black
    margins are placed directly in the bounded working image rather than
    constructing either a zoom-sized source or a large source-space pad.
    The union depends on the complete animation, so splits and seeks use the
    same input geometry and retain exactly the same motion phase.
    """
    base = (min if clip.get('fit') == 'fit' else max)(width/sw, height/sh)*clip.get('zoom', 1)
    maximum = base*(1+clip.get('zoom_amount', .15))
    positioned = bool(clip.get('offset_x', 0) or clip.get('offset_y', 0))
    ax, ay = clip.get('position_x', .5), clip.get('position_y', .5)
    dx, dy = clip.get('offset_x', 0), clip.get('offset_y', 0)

    def origin(scale, source, canvas, align, offset):
        if positioned:
            a = align if source*scale > canvas else .5
            return source*a-canvas*(a+offset)/scale
        a = align if source*base > canvas else .5
        return source*a+canvas*(.5-a)/base-canvas/(2*scale)

    samples = [base, maximum]+[scale for scale in (width/sw, height/sh) if base < scale < maximum]
    left = math.floor(min(origin(s, sw, width, ax, dx) for s in samples))-1
    top = math.floor(min(origin(s, sh, height, ay, dy) for s in samples))-1
    right = math.ceil(max(origin(s, sw, width, ax, dx)+width/s for s in samples))+1
    bottom = math.ceil(max(origin(s, sh, height, ay, dy)+height/s for s in samples))+1
    unit_w, unit_h = width/math.gcd(width, height), height/math.gcd(width, height)
    multiple = math.ceil(max((right-left)/unit_w, (bottom-top)/unit_h))
    pw, ph = unit_w*multiple, unit_h*multiple
    work_w, work_h = width*2, height*2
    factor = work_w/pw
    sx0, sy0 = max(0, left), max(0, top)
    sx1, sy1 = min(sw, left+pw), min(sh, top+ph)
    if sx1 <= sx0 or sy1 <= sy0:
        preparation = f'scale={work_w}:{work_h},drawbox=color=black:t=fill:replace=1'
    else:
        sx1, sy1 = math.ceil(sx1), math.ceil(sy1)
        px, py = max(0, round((sx0-left)*factor)), max(0, round((sy0-top)*factor))
        scaled_w = max(1, min(work_w-px, round((sx1-sx0)*factor)))
        scaled_h = max(1, min(work_h-py, round((sy1-sy0)*factor)))
        preparation = (f'crop={sx1-sx0}:{sy1-sy0}:{sx0}:{sy0}:exact=1,'
                       f'scale={scaled_w}:{scaled_h},setsar=1,'
                       f'pad={work_w}:{work_h}:{px}:{py}:black')
    progress = f"min(1,max(0,({_fmt(clip.get('in', 0)+seek)}+on/{_fmt(fps)})/{_fmt(max(1/fps, clip['duration']-1/fps))}))"
    if clip['motion'] == 'zoom_out':
        progress = f'(1-({progress}))'
    scale = f"({_fmt(base)}*(1+{_fmt(clip.get('zoom_amount', .15))}*({progress})))"

    def expression(source, canvas, align, offset, edge):
        if positioned:
            a = f'if(gt({_fmt(source)}*{scale},{canvas}),{_fmt(align)},0.5)'
            start = f'({_fmt(source)}*({a})-{canvas}*(({a})+({_fmt(offset)}))/{scale})'
        else:
            a = align if source*base > canvas else .5
            start = f'({_fmt(source*a+canvas*(.5-a)/base)}-{canvas}/(2*{scale}))'
        return f'(({start})-({_fmt(edge)}))*{_fmt(factor)}'

    x = expression(sw, width, ax, dx, left)
    y = expression(sh, height, ay, dy, top)
    return (preparation+f",zoompan=z='{_fmt(pw/width)}*{scale}':x='{x}':y='{y}':"
            f'd={math.ceil(remaining*fps)}:s={width}x{height}:fps={_fmt(fps)}')


def _with_grading(repair, framing, clip, scratch, prefix):
    """Order primary and crayon grading around framing for fast live previews.

    Spatial crayon styling runs after scaling to preview/output size so HD/4K
    footage avoids preview buffering, while remaining before black fit/offset
    padding and before still-image zoompan so borders stay black and stills
    stylize once.
    """
    grade = color_grading.filters(clip, scratch, prefix=prefix)
    if not grade:
        return ','.join(repair + [framing])
    if not color_grading.crayon_active(clip):
        return ','.join(repair + grade + [framing])
    if ',drawbox=color=black:t=fill:replace=1' in framing:
        return ','.join(repair + [framing])
    for marker in (',pad=', ',zoompan='):
        if marker in framing:
            before, after = framing.split(marker, 1)
            return ','.join(repair + [before] + grade) + marker + after
    return ','.join(repair + [framing] + grade)


def _graph(project, preview=False, scratch=None, audio_only=False, cancel=None, origin=0, video_only=False,
           preview_edge=640, picture_start=None, proxies=None, clip_origin=None, window_end=None,
           prepared_layers=False, global_rows=None, frame_range=None, video_threads=1):
    if not prepared_layers and any(clip.get('transition')=='match_move' for clip in project['clips']):
        from . import animations
        project=copy.deepcopy(project)
        project['layers']=animations.prepare_layers(project)
    # Attached element sounds follow their saved entry/exit timing. Treat them
    # as ephemeral mix inputs, keeping the user's timeline and media untouched.
    if not video_only and not project.get('_original_speech_only'):
        sounds=[item for item in project.get('layers',[])+project.get('captions',[])
                if item.get('sound_effect',{}).get('preset','none')!='none']
        if sounds:
            from . import sound_mix
            from .model import new_audio
            project=copy.deepcopy(project)
            if scratch is None:raise RenderError('Layer sounds need a temporary working folder.')
            path=sound_mix.mix(project,scratch,cancel)
            if path is not None:project['audio'].append(new_audio(path))
    # For live seeking, omit completed main clips. Keep the original global
    # timestamps for music, captions and overlays, including effect history.
    if clip_origin is not None:
        origin = float(clip_origin)
    elif origin:
        project = copy.deepcopy(project)
        project['clips'] = [clip for clip, row in zip(project['clips'], timeline(project))
                            if row['start'] >= origin-0.0000001]
    width, height = int(project["width"]), int(project["height"])
    if preview:
        width, height = preview_dimensions(project, preview_edge)
    fps = float(project.get("fps", 30))
    args = []
    filters = []
    rows = timeline(project)
    total = project_duration(project) + origin
    clips = project['clips']
    skip=0
    if not audio_only and picture_start is not None:
        limit=max(0,rows[0]['duration']-rows[0]['overlap']-2/fps)
        from fractions import Fraction
        source_fps=fps if is_still(clips[0]) else probe(clips[0]['path'])['fps']
        ratio=Fraction(source_fps/fps*clips[0].get('speed',1)).limit_denominator(10000)
        frames=ratio.denominator
        skip=math.floor(max(0,min(limit,picture_start-origin-2/fps))*fps/frames)*frames/fps
    for index, clip in enumerate(clips):
        duration = clip_duration(clip)
        speed = clip.get("speed", 1)
        seek=skip if index==0 else 0
        remaining=duration-seek
        proxy = None
        video_input=args.count('-i')
        if is_card(clip):
            metadata = {'has_video': True, 'has_audio': False, 'video_index': 0,
                        'width': width, 'height': height, 'sample_aspect_ratio': 1}
            args += ['-f', 'lavfi', '-i', f"color=c=0x{clip['color'][1:]}:s={width}x{height}:r={_fmt(fps)}:d={_fmt(remaining)}"]
        elif is_image(clip):
            metadata = {'has_video': True, 'has_audio': False, 'video_index': 0}
            if not audio_only:
                if scratch is None:raise RenderError('Images need a temporary working folder.')
                source = _image_source(clip['path'], Path(scratch)/f'scene-{index}.png')
                from gi.repository import GdkPixbuf
                _, image_width, image_height = GdkPixbuf.Pixbuf.get_file_info(source)
                metadata.update(width=image_width, height=image_height, sample_aspect_ratio=1)
                args += ['-threads', '1', '-i', source]
        else:
            metadata = probe(clip["path"])
            if not metadata["has_video"]:
                raise RenderError(f"{Path(clip['path']).name} has no video stream.")
            proxy = (proxies or {}).get(clip['path']) if preview and not audio_only and not watermark.active(clip) else None
            decode_threads = str(max(1, int(video_threads)))
            args += ["-threads", decode_threads, "-ss", _fmt(clip.get("in", 0)+seek*speed), "-t", _fmt(clip["out"] - clip["in"]-seek*speed), "-i", proxy or clip["path"]]
        # Correct non-square source pixels before placing them in a square-pixel canvas.
        framing = "scale=trunc(iw*sar/2)*2:ih,setsar=1,"
        rotation = clip.get("rotation", 0)
        if rotation == 90:
            framing += "transpose=clock,"
        elif rotation == 180:
            framing += "hflip,vflip,"
        elif rotation == 270:
            framing += "transpose=cclock,"
        if clip.get("flip_x"):
            framing += "hflip,"
        if clip.get("flip_y"):
            framing += "vflip,"
        moving = is_image(clip) and clip.get('motion', 'none') != 'none' and clip.get('zoom_amount', .15) > 0
        # Supersample the still before zoompan to avoid whole-pixel stepping
        # during a slow move. Only one source frame is held at this size.
        frame_width, frame_height = (width*2, height*2) if moving else (width, height)
        zoom = clip.get('zoom', 1)
        positioned = bool(clip.get('offset_x', 0) or clip.get('offset_y', 0))
        bounded_motion = moving and (zoom > 1 or positioned)
        if zoom > 1 or positioned:
            source_meta = probe(proxy) if not is_still(clip) and proxy else metadata
            sar = source_meta.get('decoded_sample_aspect_ratio', source_meta.get('sample_aspect_ratio', 1))
            source_w = max(2, math.trunc(source_meta.get('width', width)*sar/2)*2)
            source_h = source_meta.get('height', height)
            if rotation in (90, 270):source_w, source_h = source_h, source_w
            if bounded_motion:
                framing += _bounded_image_motion(clip, source_w, source_h, width, height, fps, seek, remaining)
            else:
                framing += _bounded_clip_frame(clip, source_w, source_h, width, height)
        elif clip.get("fit", "fill") == "fit":
            framing += f"scale={frame_width}:{frame_height}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad={frame_width}:{frame_height}:(ow-iw)/2:(oh-ih)/2:black"
        else:
            x, y = _fmt(clip.get("position_x", 0.5)), _fmt(clip.get("position_y", 0.5))
            framing += f"scale={frame_width}:{frame_height}:force_original_aspect_ratio=increase:force_divisible_by=2,crop={frame_width}:{frame_height}:(iw-ow)*{x}:(ih-oh)*{y}"
        if moving and not bounded_motion:
            progress = f"min(1,max(0,({_fmt(clip.get('in', 0)+seek)}+on/{_fmt(fps)})/{_fmt(max(1/fps, clip['duration']-1/fps))}))"
            if clip['motion'] == 'zoom_out':progress = f'(1-({progress}))'
            framing += (f",zoompan=z='1+{_fmt(clip.get('zoom_amount', .15))}*({progress})':"
                        f"x='(iw-iw/zoom)/2':y='(ih-ih/zoom)/2':"
                        f"d={math.ceil(remaining*fps)}:s={width}x{height}:fps={_fmt(fps)}")
        picture_index = 0 if proxy else metadata['video_index']
        repair = []
        if clip.get('sparkle_patch') and not audio_only:
            source_start = clip.get('in', 0) + seek * speed
            source_end = clip['out']
            if window_end is not None:
                clip_start = (global_rows[index]['start'] if global_rows is not None else origin + rows[index]['start'])
                source_end = min(source_end, clip.get('in', 0) + max(0.05, window_end - clip_start + 2 / fps) * speed)
            repair = watermark.removal_filter(
                clip['sparkle_patch'], metadata, scratch,
                source_start=source_start,
                source_end=source_end,
            )
        if clip.get('watermark_region') and not audio_only:
            repair.extend(watermark.region_filters(clip['watermark_region'], metadata))
        preparation = _with_grading(repair, framing, clip, scratch, f'cg{index}_')
        picture = [f"[{video_input}:{picture_index}]{preparation}", "setsar=1", "format=yuv420p",
                   f"setpts=(PTS-STARTPTS)/{_fmt(speed)}", f"tpad=stop_mode=clone:stop_duration={_fmt(remaining)}",
                   f"trim=duration={_fmt(remaining)}", f"fps={_fmt(fps)}", "settb=AVTB"]
        picture_fade_in = min(float(clip.get("video_fade_in", 0)), duration)
        picture_fade_out = min(float(clip.get("video_fade_out", 0)), duration)
        if picture_fade_in > 0 or picture_fade_out > 0:
            seek_us = round(seek * 1000000)
            if seek_us:picture.append(f"setpts=PTS+{seek_us}")
            if picture_fade_in > 0:
                picture.append(f"fade=t=in:st=0:d={_fmt(picture_fade_in)}")
            if picture_fade_out > 0:
                picture.append(f"fade=t=out:st={_fmt(duration-picture_fade_out)}:d={_fmt(picture_fade_out)}")
            if seek_us:picture.append(f"setpts=PTS-{seek_us}")
        if not audio_only:
            filters.append(",".join(picture) + f"[v{index}]")
        if video_only:
            continue
        if metadata["has_audio"] and clip.get("volume", 1) > 0:
            audio_input=video_input
            if seek or (preview and (picture_start is not None or (proxies or {}).get(clip.get('path')))):
                # Independent audio reads also prevent the live mix from
                # pulling future clips' pictures through a shared demuxer.
                # Keep trimmed audio history for echo/compression/envelopes;
                # explicitly disable video on this input.
                audio_input=args.count('-i')
                args += ['-threads','1','-vn','-ss',_fmt(clip.get('in',0)),
                         '-t',_fmt(clip['out']-clip.get('in',0)),'-i',clip['path']]
            parts = [f"[{audio_input}:{metadata['audio_index']}]aresample=48000",
                     "aformat=sample_fmts=fltp:channel_layouts=stereo", "asetpts=PTS-STARTPTS"]
            parts.extend(_processed_audio(clip,duration))
            filters.append(",".join(parts) + f"[a{index}]")
        else:
            filters.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={_fmt(duration)},asetpts=PTS-STARTPTS[a{index}]")
    video, audio = "v0", "a0"
    running_duration = rows[0]["duration"]-skip
    running_frames = round(running_duration*fps)
    for index in range(1, len(clips)):
        overlap = rows[index - 1]["overlap"]
        if overlap:
            if not audio_only:
                from . import transition_render
                if global_rows is not None or origin or skip:
                    full_offset = (global_rows[index]['start'] if global_rows is not None
                                   else origin + skip + running_duration - overlap)
                    first_full = transition_render._first_frame(full_offset, fps)
                    start_frame = round((origin + skip) * fps)
                    local_first = max(0, first_full - start_frame)
                    delta_us = math.floor(full_offset * 1000000 + 1e-6) - transition_render._frame_us(first_full, fps)
                    join_offset = max(0.0, (transition_render._frame_us(local_first, fps) + delta_us) / 1000000)
                else:
                    join_offset = running_duration - overlap
                transition_render.append(args,filters,video,f'v{index}',clips[index-1],
                                         overlap,join_offset,width,height,fps,
                                         rows[index]['duration'],scratch,index,cancel,
                                         with_alpha=bool(project.get('layers') or project.get('captions')),
                                         left_frames=running_frames)
                running_frames = transition_render._first_frame(join_offset,fps)+round(rows[index]['duration']*fps)
            if not video_only:
                filters.append(f"[{audio}][a{index}]acrossfade=d={_fmt(overlap)}:c1=tri:c2=tri[joina{index}]")
        else:
            if not audio_only:
                filters.append(f"[{video}][v{index}]concat=n=2:v=1:a=0,fps={_fmt(fps)},settb=AVTB[joinv{index}]")
                running_frames += round(rows[index]['duration']*fps)
            if not video_only:
                filters.append(f"[{audio}][a{index}]concat=n=2:v=0:a=1[joina{index}]")
        video, audio = f"joinv{index}", f"joina{index}"
        running_duration += rows[index]["duration"] - overlap
    if origin or skip:
        if not audio_only:
            # Quantize the shifted picture back onto the composition frame
            # grid. Adding rounded microseconds can turn .1 into .099999 and
            # make an output seek skip the requested animation frame.
            filters.append(f'[{video}]settb=expr=1/{_fmt(fps)},setpts=PTS+round({_fmt(origin+skip)}*{_fmt(fps)}),settb=AVTB[globalvideo]')
            video = 'globalvideo'
        if not video_only:
            filters.append(f'[{audio}]adelay={round(origin*1000)}:all=1,asetpts=N/SR/TB[globalaudio]')
            audio = 'globalaudio'
    mix_labels = [audio]
    for offset, track in enumerate([] if video_only else _continuous_audio(project.get("audio", []))):
        index = args.count('-i')
        length = clip_duration(track)
        start = float(track.get("start", 0))
        metadata = probe(track["path"])
        if not metadata["has_audio"]:
            raise RenderError(f"{Path(track['path']).name} has no audio stream.")
        source_args, source_trim = _audio_input(track, metadata)
        args += source_args
        if source_trim:source_trim += 'asetpts=PTS-STARTPTS,'
        parts = [f"[{index}:{metadata['audio_index']}]{source_trim}aresample=48000",
                 "aformat=sample_fmts=fltp:channel_layouts=stereo", "asetpts=PTS-STARTPTS"]
        audible_length = max(0.0, min(length, total - start))
        parts.extend(_processed_audio(track,length,audible_length))
        # Give the delayed sample sequence an explicit zero origin. With tempo
        # conversion/padding, inherited timestamps can otherwise cause amix to
        # discard the leading silence and start this independent track early.
        parts.extend([f"adelay={round(start*48000)}S:all=1", "asetpts=N/SR/TB",
                      f"apad=whole_dur={_fmt(total)}", f"atrim=duration={_fmt(total)}"])
        filters.append(",".join(parts) + f"[music{offset}]")
        mix_labels.append(f"music{offset}")
    if not video_only:
        norm_labels = []
        for idx, label in enumerate(mix_labels):
            norm = f'amixin{idx}'
            filters.append(f'[{label}]asetnsamples=n=1024:p=0[{norm}]')
            norm_labels.append(norm)
        filters.append("".join(f"[{label}]" for label in norm_labels) + f"amix=inputs={len(norm_labels)}:duration=longest:dropout_transition=0:normalize=0,alimiter=limit=0.95:level=0:latency=1,apad,atrim=duration={_fmt(total)},asetnsamples=n=1024:p=0[outaudio]")
    if not audio_only:
        vis_start = 0.0
        vis_end = None
        vis_total = total
        if window_end is not None or clip_origin is not None:
            vis_start = max(0.0, (picture_start if picture_start is not None else origin) - 2 / fps)
            vis_total = max(total, float(window_end)) if window_end is not None else total
            vis_end = vis_total if window_end is None else min(vis_total, float(window_end))
        video = _visual_graph(project, args, filters, video, width, height, fps, vis_total, scratch, cancel,
                              window_start=vis_start, window_end=vis_end)
        if frame_range is not None:
            start_frame = round((origin + skip) * fps) if (origin or skip) else 0
            drop = max(0, int(frame_range[0]) - start_frame)
            end_f = max(drop, int(frame_range[1]) - start_frame)
            filters.append(f"[{video}]trim=start_frame={drop}:end_frame={end_f},setpts=PTS-STARTPTS,format=yuv420p[outvideo]")
        else:
            filters.append(f"[{video}]format=yuv420p[outvideo]")
    return args, ";\n".join(filters), total


def preview_frame(project, seconds, cancel=None, preview_edge=640):
    """Read one composed RGB frame for interactive, silent playhead dragging.

    Seek into the active source at aligned source/composition frame boundaries,
    skipping completed clips and inactive layers/captions. Keep future clip joins
    so color-format negotiation matches playback, with no soundtrack decoding
    or video file.
    """
    project = copy.deepcopy(project)
    _source_rate(project)
    validate_project(project, check_files=True, require_clips=True)
    if any(clip.get('transition')=='match_move' for clip in project['clips']):
        from . import animations
        project['layers']=animations.prepare_layers(project)
    seconds = max(0, min(float(seconds), project_duration(project)-1/project['fps']))
    # FFmpeg's output seek chooses the next frame on the composition grid.
    # Include cues/overlays entering on that frame, even just after the pointer.
    seconds = math.ceil(seconds*project['fps']-1e-7)/project['fps']
    all_rows = timeline(project)
    active = [(i, row) for i, row in enumerate(all_rows)
              if row['start'] <= seconds < row['start']+row['duration']]
    first_idx, origin = active[0][0], active[0][1]['start']
    end_idx = min(len(project['clips']), active[-1][0]+2)
    # Only the active scenes and their immediate successor can affect this
    # picture. Retain that join for color negotiation, but avoid decoding and
    # rasterizing an entire project's future scenes for every pointer move.
    project['clips'] = project['clips'][first_idx:end_idx]
    slice_rows = all_rows[first_idx:end_idx]
    project['audio'] = []
    for group in ('layers', 'captions'):
        project[group] = [item for item in project[group] if item['start'] <= seconds < item['end']]
    width, height = preview_dimensions(project, preview_edge)
    with tempfile.TemporaryDirectory(prefix='clipcanvas-frame-') as scratch:
        from . import preview_cache
        proxies = {}
        for clip in project['clips']:
            if not is_still(clip):
                proxy = preview_cache.lease_available(clip['path'], preview_edge, scratch)
                if proxy:proxies[clip['path']] = proxy
        args, graph, _ = _graph(
            project, True, scratch, cancel=cancel, video_only=True,
            preview_edge=preview_edge, picture_start=seconds, proxies=proxies,
            clip_origin=origin, window_end=seconds + 2 / project['fps'],
            prepared_layers=True, global_rows=slice_rows,
        )
        graph_path = Path(scratch)/'filters.txt'
        graph_path.write_text(graph, encoding='utf-8')
        picture = Path(scratch)/'picture.rgb'
        arguments = ['-nostdin', '-hide_banner', '-loglevel', 'error', '-y',
                     '-filter_complex_threads', '1'] + args + [
                     '-filter_complex_script', str(graph_path), '-ss', _fmt(seconds),
                     '-map', '[outvideo]', '-an', '-frames:v', '1', '-threads', '1',
                     '-c:v', 'rawvideo', '-pix_fmt', 'rgb24', '-f', 'rawvideo',
                     '-progress', 'pipe:1', str(picture)]
        _execute(arguments, 1/project['fps'], None, cancel, Path(scratch)/'ffmpeg.log')
        pixels = picture.read_bytes()
        if len(pixels) != width*height*3:
            raise RenderError('Could not read a frame at this timeline position.')
        return {'pixels': pixels, 'width': width, 'height': height, 'position': seconds}


def live_stream(project, start=0, cancel=None, preview_edge=640, status=None):
    """Yield a bounded, unencoded Matroska stream for immediate native playback.

    Raw I420 video and stereo PCM retain the export graph's effects/mix. HD/Fast
    use available cached videos immediately and prepare missing ones in the
    background for later plays/seeks; audio always reads the originals. The
    consumer supplies backpressure, so we never generate a whole preview file.
    Closing the generator or setting cancel stops FFmpeg and removes sprites.
    """
    project = copy.deepcopy(project)
    _source_rate(project)
    try:
        validate_project(project, check_files=True, require_clips=True)
    except ValueError as error:
        raise RenderError(str(error)) from error
    seconds = project_duration(project)
    start = max(0, min(float(start), max(0, seconds-1/project['fps'])))
    active = [row for row in timeline(project) if row['start'] <= start < row['start']+row['duration']]
    origin = active[0]['start'] if active else 0
    binary, env = _tool('ffmpeg')
    with tempfile.TemporaryDirectory(prefix='clipcanvas-live-') as scratch:
        from . import preview_cache
        proxies = {}
        paths = []
        if preview_edge:
            for clip, row in zip(project['clips'], timeline(project)):
                if is_still(clip) or row['start']+row['duration']<=origin or clip['path'] in paths:continue
                paths.append(clip['path'])
                proxy = preview_cache.lease_available(clip['path'], preview_edge, scratch)
                if proxy:proxies[clip['path']] = proxy
            if status:status('Loading preview…')
        args, graph, total = _graph(project, True, scratch, cancel=cancel, origin=origin,
                                    preview_edge=preview_edge, picture_start=start, proxies=proxies)
        # acrossfade can emit half-second PCM blocks. Packetize without changing
        # samples so clocked audio receives small, regular buffers at every join.
        graph += ';\n[outaudio]asetnsamples=n=1024:p=0[liveaudio]'
        if cancel is not None and cancel.is_set():
            return
        graph_path = Path(scratch)/'filters.txt'
        graph_path.write_text(graph, encoding='utf-8')
        arguments = [binary, '-nostdin', '-hide_banner', '-loglevel', 'error',
                     '-filter_complex_threads', '1'] + args + [
                     '-filter_complex_script', str(graph_path), '-ss', _fmt(start),
                     '-map', '[outvideo]', '-map', '[liveaudio]',
                     '-c:v', 'rawvideo', '-pix_fmt', 'yuv420p', '-threads', '1',
                     '-c:a', 'pcm_s16le', '-ar', '48000', '-ac', '2',
                     '-t', _fmt(seconds-start), '-flush_packets', '1', '-f', 'matroska', 'pipe:1']
        with preview_cache.PreviewWarmup(paths, preview_edge, cancel), open(Path(scratch)/'ffmpeg.log', 'wb') as log:
            process = subprocess.Popen(arguments, stdout=subprocess.PIPE, stderr=log,
                                       stdin=subprocess.DEVNULL, env=env)
            # Reading stdout can block before the first frame or on damaged
            # media. A watcher also cancels those cases without waiting for data.
            finished = threading.Event()
            def watch():
                while not finished.wait(.05):
                    if cancel is not None and cancel.is_set():
                        _stop(process, immediate=True)
                        return
            watcher = threading.Thread(target=watch, daemon=True)
            watcher.start()
            try:
                while cancel is None or not cancel.is_set():
                    data = process.stdout.read(65536)
                    if not data:
                        break
                    yield data
                if cancel is not None and cancel.is_set():
                    return
                if process.wait():
                    log.flush()
                    detail = (Path(scratch)/'ffmpeg.log').read_text(errors='replace')[-1600:]
                    raise RenderError('Live preview could not play this project.\n' + detail)
            finally:
                finished.set()
                _stop(process, immediate=True)
                process.stdout.close()
                watcher.join(timeout=4)


EXPORT_PRESETS = {'fast': 'veryfast', 'balanced': 'medium', 'compact': 'slow'}
EXPORT_ENCODINGS = ('auto', 'software')


def _render_filter_threads(preview):
    # Export can share slice-capable filters between two workers. Keep the
    # preview budget and per-input decoder limits independent; a large graph
    # must not create a CPU-sized thread pool for every source.
    return 1 if preview else min(2, os.cpu_count() or 1)


def _vaapi_encoding(quality, speed):
    # VAAPI CQP and x264 CRF are different quality scales. Keep their mappings
    # explicit; a matching numeric value does not imply matching visual quality.
    return ['-c:v', 'h264_vaapi', '-rc_mode', 'CQP', '-qp',
            {'master': '14', 'high': '18', 'smaller': '23'}[quality],
            '-compression_level', {'fast': '7', 'balanced': '4', 'compact': '1'}[speed]]


def _probe_vaapi(device, width, height, fps, quality, speed, cancel=None, timeout=4):
    """Actually encode at the requested size/settings, with bounded cancellation.

    Build-time encoder listings cannot establish that a driver/device works.
    Called only from the render worker, never GTK's main thread.
    """
    if cancel is not None and cancel.is_set():
        raise RenderCancelled('Export cancelled.')
    binary, env = _tool('ffmpeg')
    with tempfile.TemporaryDirectory(prefix='clipcanvas-hardware-probe-') as scratch:
        output = Path(scratch)/'probe.mp4'
        with (Path(scratch)/'probe.log').open('wb') as log:
            try:
                process = subprocess.Popen([binary, '-nostdin', '-hide_banner', '-loglevel', 'error',
                    '-y', '-vaapi_device', str(device), '-filter_threads', '1', '-f', 'lavfi',
                    '-i', f'color=black:s={width}x{height}:r={_fmt(fps)}',
                    '-vf', 'format=nv12,hwupload', '-frames:v', '2'] +
                    _vaapi_encoding(quality, speed) + ['-an', str(output)],
                    stdout=subprocess.DEVNULL, stderr=log, stdin=subprocess.DEVNULL, env=env)
            except OSError:
                return False
            deadline = time.monotonic()+timeout
            try:
                while process.poll() is None:
                    if cancel is not None and cancel.is_set():
                        raise RenderCancelled('Export cancelled.')
                    if time.monotonic() >= deadline:
                        return False
                    if cancel is not None:
                        cancel.wait(.025)
                    else:
                        time.sleep(.025)
                if cancel is not None and cancel.is_set():
                    raise RenderCancelled('Export cancelled.')
                return process.returncode == 0 and output.is_file() and output.stat().st_size > 0
            finally:
                _stop(process, immediate=True)


def _vaapi_device(width, height, fps, quality, speed, cancel=None):
    """Select a currently usable Linux render node; do not cache driver failures."""
    for device in sorted(Path('/dev/dri').glob('renderD*'))[:4]:
        if cancel is not None and cancel.is_set():
            raise RenderCancelled('Export cancelled.')
        if (device.is_char_device() and os.access(device, os.R_OK | os.W_OK)
                and _probe_vaapi(device, width, height, fps, quality, speed, cancel)):
            return device
    return None


def render(project, output, preview=False, progress=None, cancel=None, quality="high", preview_edge=640, speed="fast", encoding="software"):
    """Render synchronously; progress receives (fraction_0_to_1, message).

    Call from a background worker. Prepared preview uses preview_edge (640 by
    default) and a fast encoder. Choices: high (CRF 18), smaller (23), master (14).
    Lossless uses FFV1/float PCM in MKV, preserving the composed frames/audio.
    Source decoding, scaling, compositing and 8-bit YUV conversion still apply.
    MP4 speed is independent of quality: fast (veryfast), balanced (medium), or
    compact (slow). Presets trade encoding time against compression efficiency;
    equal CRF values across presets do not promise identical visual quality.
    Preview and lossless encoding ignore speed.
    Automatic encoding probes VAAPI at the actual canvas size, then falls back
    to software if unavailable or if hardware rendering fails. Preview/lossless
    ignore encoding. The API retains software as its default.
    """
    project = copy.deepcopy(project)
    _source_rate(project)
    try:
        validate_project(project, check_files=True, require_clips=True)
    except ValueError as error:
        raise RenderError(str(error)) from error
    if quality not in ("high", "smaller", "master", "lossless"):
        raise RenderError("Choose high, smaller, master or lossless export quality.")
    if not isinstance(speed, str) or speed not in EXPORT_PRESETS:
        raise RenderError("Choose fast, balanced or compact export speed.")
    if encoding not in EXPORT_ENCODINGS:
        raise RenderError('Choose automatic or software encoding.')
    output = Path(output).expanduser().resolve()
    for item in media_items(project):
        source = Path(item["path"]).resolve()
        if source == output or (output.exists() and os.path.samefile(source, output)):
            raise RenderError("Choose a different export filename. Your original media will never be overwritten.")
    if project.get("_project_path") and output == Path(project["_project_path"]).resolve():
        raise RenderError("Choose an export filename different from the project file.")
    if output.is_dir():
        raise RenderError("Choose a video filename, not a folder.")
    if not output.parent.is_dir():
        raise RenderError("The export folder does not exist. Choose an existing folder.")
    if cancel is not None and cancel.is_set():
        raise RenderCancelled("Export cancelled.")
    if progress:
        progress(0.0, "Preparing your video…")
    lossless = quality == 'lossless' and not preview
    if lossless and output.suffix.lower() != '.mkv':
        raise RenderError('Choose an .mkv filename for the lossless master.')
    handle, temporary = tempfile.mkstemp(prefix=".clipcanvas-", suffix=".mkv" if lossless else ".mp4", dir=str(output.parent))
    os.close(handle)
    try:
        with tempfile.TemporaryDirectory(prefix="clipcanvas-render-") as scratch:
            input_args, graph, seconds = _graph(project, preview, scratch=scratch, cancel=cancel, preview_edge=preview_edge)
            graph_path = Path(scratch) / "filters.txt"
            graph_path.write_text(graph, encoding="utf-8")
            device = None
            if encoding == 'auto' and not preview and not lossless:
                if progress:
                    progress(0.0, 'Testing graphics hardware…')
                device = _vaapi_device(project['width'], project['height'], project['fps'], quality, speed, cancel)
                if device is None and progress:
                    progress(0.0, 'Graphics encoding unavailable. Using software…')
            if lossless:
                software_encoding = ['-c:v', 'ffv1', '-level', '3', '-g', '1', '-slicecrc', '1',
                            '-pix_fmt', 'yuv420p', '-c:a', 'pcm_f32le']
            else:
                crf = "18" if preview else {"high": "18", "smaller": "23", "master": "14"}[quality]
                software_encoding = ['-c:v', 'libx264', '-preset', 'ultrafast' if preview else EXPORT_PRESETS[speed],
                            '-crf', crf, '-pix_fmt', 'yuv420p', '-c:a', 'aac',
                            '-b:a', '192k' if preview else '320k', '-movflags', '+faststart']
            for active_device in ((device, None) if device is not None else (None,)):
                selected_graph = graph_path
                video_label = '[outvideo]'
                device_args = []
                selected_encoding = software_encoding
                if active_device is not None:
                    # Only the final composed frames move to the GPU. The same
                    # original-source composition/audio graph is reused on retry.
                    selected_graph = Path(scratch)/'filters-hardware.txt'
                    selected_graph.write_text(graph+';\n[outvideo]format=nv12,hwupload[hardwarevideo]', encoding='utf-8')
                    video_label = '[hardwarevideo]'
                    device_args = ['-vaapi_device', str(active_device)]
                    selected_encoding = _vaapi_encoding(quality, speed) + [
                        '-c:a', 'aac', '-b:a', '320k', '-movflags', '+faststart']
                message = ('Rendering preview…' if preview else
                           'Rendering with graphics hardware…' if active_device is not None else
                           'Rendering with software…')
                if progress:
                    progress(0.0, message)
                def report(value, detail):
                    if progress:
                        progress(value, message)
                arguments = ["-nostdin", "-hide_banner", "-loglevel", "warning", "-y",
                             "-filter_complex_threads", str(_render_filter_threads(preview))] + device_args + input_args + [
                             "-filter_complex_script", str(selected_graph), "-map", video_label, "-map", "[outaudio]"] + selected_encoding + [
                             "-threads", str(min(4, os.cpu_count() or 2)), "-ar", "48000", "-ac", "2", "-t", _fmt(seconds),
                             "-max_muxing_queue_size", "2048", "-progress", "pipe:1", "-stats_period", "0.2", temporary]
                try:
                    _execute(arguments, seconds, report, cancel, Path(scratch)/('hardware.log' if active_device is not None else 'ffmpeg.log'))
                    break
                except RenderCancelled:
                    raise
                except RenderError:
                    if active_device is None:
                        raise
                    if cancel is not None and cancel.is_set():
                        raise RenderCancelled('Export cancelled.') from None
                    if progress:
                        progress(0.0, 'Graphics encoding failed. Retrying with software…')
        if cancel is not None and cancel.is_set():
            raise RenderCancelled("Export cancelled.")
        if not Path(temporary).stat().st_size:
            raise RenderError("FFmpeg produced an empty export.")
        os.replace(temporary, output)
        if progress:
            progress(1.0, "Preview ready." if preview else "Export complete.")
        return str(output)
    except OSError as error:
        raise RenderError(f"Could not save the video: {error}") from error
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def _source_rate(project):
    """Resolve older projects too, without blocking the desktop thread."""
    first = next((clip for clip in project.get('clips', []) if not is_still(clip)), None)
    if first and first.get('path'):
        first['source_fps'] = probe(first['path'])['fps']
    adapt_frame_rate(project)


def render_audio(project, output, source='mix', progress=None, cancel=None):
    """Write composed speech-recognition audio as a local 16 kHz mono WAV.

    ``video`` includes the trimmed/speed-adjusted main clips with original audio
    restored even when a clip was muted after extraction. ``mix`` follows the
    audible project including independent soundtracks and attached layer sounds.
    Original-video speech excludes element sounds. This operation never
    rasterizes or encodes a picture.
    """
    if source not in ('mix', 'video'):
        raise RenderError('Choose original video speech or the full audio mix.')
    project = copy.deepcopy(project)
    protected_media = media_items(project)
    if source == 'video':
        project['_original_speech_only']=True
        project['audio'] = []
        for item in project.get('layers',[])+project.get('captions',[]):
            item.pop('sound_effect',None)
        for clip in project.get('clips', []):
            clip['volume'] = 0.0 if is_still(clip) else 1.0
            clip.pop('audio_effects',None)
    try:
        validate_project(project, check_files=True, require_clips=True)
    except ValueError as error:
        raise RenderError(str(error)) from error
    output = Path(output).expanduser().resolve()
    for item in protected_media:
        source_path = Path(item['path']).resolve()
        if source_path == output or (output.exists() and source_path.exists() and os.path.samefile(source_path, output)):
            raise RenderError('Choose a different audio filename. Your original media will never be overwritten.')
    if project.get('_project_path') and output == Path(project['_project_path']).resolve():
        raise RenderError('Choose an audio filename different from the project file.')
    if not output.parent.is_dir() or output.is_dir():
        raise RenderError('Choose an audio filename in an existing folder.')
    if cancel is not None and cancel.is_set():
        raise RenderCancelled('Caption generation cancelled.')
    if progress:
        progress(0.0, 'Preparing speech audio…')
    handle, temporary = tempfile.mkstemp(prefix='.clipcanvas-', suffix='.wav', dir=str(output.parent))
    os.close(handle)
    try:
        with tempfile.TemporaryDirectory(prefix='clipcanvas-speech-') as scratch:
            inputs, graph, seconds = _graph(project, audio_only=True, scratch=scratch, cancel=cancel)
            graph_path = Path(scratch)/'audio-filters.txt'
            graph_path.write_text(graph, encoding='utf-8')
            arguments = ['-nostdin', '-hide_banner', '-loglevel', 'warning', '-y', '-filter_complex_threads', '1'] + inputs + [
                '-filter_complex_script', str(graph_path), '-map', '[outaudio]', '-vn', '-c:a', 'pcm_s16le',
                '-ar', '16000', '-ac', '1', '-t', _fmt(seconds), '-progress', 'pipe:1', '-stats_period', '0.2', temporary]
            _execute(arguments, seconds, progress, cancel, Path(scratch)/'ffmpeg.log')
        if cancel is not None and cancel.is_set():
            raise RenderCancelled('Caption generation cancelled.')
        os.replace(temporary, output)
        if progress:
            progress(1.0, 'Speech audio ready.')
        return str(output)
    except OSError as error:
        raise RenderError(f'Could not prepare speech audio: {error}') from error
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def render_track_sample(item, output, with_effects=True, audible_length=None, seconds=12, cancel=None):
    """Audition the first seconds of one edited audio item without its mix.

    Writes a protected, atomic 48 kHz stereo WAV. The final mix limiter is
    reproduced here for an isolated track; other tracks can affect it in a mix.
    """
    from . import model
    item=copy.deepcopy(item)
    project=model.new_project();project['audio']=[item]
    validate_project(project,check_files=True)
    metadata=probe(item['path'])
    if not metadata['has_audio']:raise RenderError('This item has no audio to audition.')
    output=Path(output).expanduser().resolve();source=Path(item['path']).resolve()
    if source==output or (output.exists() and os.path.samefile(source,output)):
        raise RenderError('An audition cannot replace its original audio.')
    if not output.parent.is_dir() or output.is_dir():raise RenderError('Choose an audio filename in an existing folder.')
    length=clip_duration(item)
    audible_length=length if audible_length is None else max(0,min(length,audible_length))
    seconds=min(float(seconds),audible_length)
    if seconds<=0 or not math.isfinite(seconds):raise RenderError('This track has no audible section in the video.')
    handle,temporary=tempfile.mkstemp(prefix='.clipcanvas-',suffix='.wav',dir=output.parent);os.close(handle)
    try:
        with tempfile.TemporaryDirectory(prefix='clipcanvas-audition-') as scratch:
            source_args, source_trim = _audio_input(item, metadata)
            if source_trim:source_trim += 'asetpts=PTS-STARTPTS,'
            filters=[source_trim+'aresample=48000','aformat=sample_fmts=fltp:channel_layouts=stereo','asetpts=PTS-STARTPTS']
            filters.extend(_processed_audio(item,length,audible_length,with_effects))
            filters.extend(['alimiter=limit=0.95:level=0:latency=1','apad',f'atrim=duration={_fmt(seconds)}'])
            args=['-nostdin','-hide_banner','-loglevel','warning','-y']+source_args+[
                  '-map',f'0:{metadata["audio_index"]}','-vn','-filter_threads','1','-af',','.join(filters),
                  '-c:a','pcm_s16le','-ar','48000','-ac','2','-t',_fmt(seconds),
                  '-progress','pipe:1',temporary]
            _execute(args,seconds,None,cancel,Path(scratch)/'audition.log')
        if cancel is not None and cancel.is_set():raise RenderCancelled('Audition cancelled.')
        os.replace(temporary,output);return str(output)
    finally:
        try:os.unlink(temporary)
        except FileNotFoundError:pass


def thumbnail(path, output, at=0, width=320, height=180, watermark_region=None):
    """Write a thumbnail inside the requested bounds, without padding.

    Its real aspect ratio lets the UI apply the same fit/crop as the renderer.
    """
    binary, env = _tool("ffmpeg")
    meta = probe(path)
    if not meta["has_video"]:
        raise RenderError("This file has no video thumbnail.")
    repair = watermark.region_filters(watermark_region, meta) if watermark_region else []
    at = max(0, min(float(at), max(0, meta["duration"] - 0.08)))
    output = Path(output).expanduser().resolve()
    source = Path(path).expanduser().resolve()
    if output == source or (output.exists() and os.path.samefile(source, output)):
        raise RenderError("A thumbnail cannot replace its source video.")
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = subprocess.run([binary, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-threads", "1",
                                 "-ss", _fmt(at), "-i", str(Path(path).resolve()), "-map", f"0:{meta['video_index']}",
                                 "-frames:v", "1", "-vf", ",".join(repair + [f"scale=trunc(iw*sar/2)*2:ih,setsar=1,scale={int(width)}:{int(height)}:force_original_aspect_ratio=decrease,setsar=1"]),
                                 "-threads", "1", "-update", "1", str(output)],
                                capture_output=True, text=True, env=env, timeout=30)
        if result.returncode or not output.is_file():
            raise RenderError(f"Could not create the thumbnail: {result.stderr[-600:]}")
        return str(output)
    except subprocess.TimeoutExpired as error:
        raise RenderError("Creating the thumbnail took too long.") from error


def waveform(path, max_points=None, cancel=None):
    """Stream source-sample peaks over the complete media timeline.

    Keep all channels (opposite-phase stereo must not cancel) and the native
    sample rate (downsampling would remove high-frequency transients). Peaks
    retain their linear amplitude relative to digital full scale. The default
    five-millisecond bins resolve a bar even at maximum zoom and minimum speed;
    storage is bounded for unusually long recordings, without truncating time.
    """
    if cancel is not None and cancel.is_set():
        raise RenderCancelled('Waveform cancelled.')
    meta = probe(path)
    count = max(1, min(2000000, int(max_points) if max_points is not None else math.ceil(meta['duration']*200)))
    if not meta["has_audio"]:
        return array.array('f', [0.0])*count
    binary, env = _tool("ffmpeg")
    rate, channels = meta['audio_sample_rate'], meta['audio_channels']
    frames = max(1, round(meta['duration']*rate))
    count = min(count, frames)
    peaks = array.array('f', [0.0])*count
    process = subprocess.Popen([binary, '-nostdin', '-hide_banner', '-loglevel', 'error', '-threads', '1',
        '-i', str(Path(path).resolve()), '-map', f"0:{meta['audio_index']}",
        '-ar', str(rate), '-ac', str(channels), '-f', 'f32le', 'pipe:1'],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, env=env)
    finished = threading.Event(); timed_out = threading.Event()
    deadline = time.monotonic()+300
    def watch():
        while not finished.wait(.05):
            if time.monotonic()>=deadline:timed_out.set()
            if timed_out.is_set() or (cancel is not None and cancel.is_set()):
                _stop(process);return
    watcher = threading.Thread(target=watch, daemon=True);watcher.start()
    try:
        for index in range(count):
            remaining = ((index+1)*frames//count-index*frames//count)*channels*4
            peak = 0.0
            while remaining:
                data = process.stdout.read(min(65536,remaining))
                if not data:break
                remaining -= len(data)
                samples = array.array('f');samples.frombytes(data[:len(data)//4*4])
                if sys.byteorder!='little':samples.byteswap()
                if samples:peak = max(peak, abs(min(samples)), abs(max(samples)))
            peaks[index] = min(1.0,peak) if math.isfinite(peak) else 0.0
            if remaining:break
        # Drain codec padding without stretching the waveform to padded time.
        while process.stdout.read(65536):pass
        code = process.wait()
        if cancel is not None and cancel.is_set():raise RenderCancelled('Waveform cancelled.')
        if timed_out.is_set():raise RenderError('Reading this waveform took too long.')
        if code:raise RenderError("Could not read this soundtrack's waveform.")
        return peaks
    finally:
        finished.set();_stop(process);process.stdout.close();watcher.join(timeout=4)
