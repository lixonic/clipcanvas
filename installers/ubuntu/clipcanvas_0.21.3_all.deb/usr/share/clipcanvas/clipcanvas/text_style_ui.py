"""One native text-style editor shared by titles and editable captions."""
import copy
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango
from . import text_styles, visuals, bundled_fonts, caption_styles


def column(spacing=8):
    return Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing)


class TextStyleEditor:
    presets = text_styles.PRESETS

    def __init__(self, parent, style):
        self.base = copy.deepcopy(style)
        self.loading = True
        self.sample = 'Your words stay editable'
        self.preset_buttons = {}
        label = Gtk.Label(label='Text styles', xalign=0)
        label.get_style_context().add_class('section')
        parent.pack_start(label, False, False, 0)
        grid = Gtk.Grid(column_spacing=6, row_spacing=6, column_homogeneous=True)
        for index, (key, title, description) in enumerate(self.presets):
            button = Gtk.Button()
            content = column(3);content.set_border_width(4)
            preview = Gtk.DrawingArea();preview.set_size_request(126, 44)
            preview.connect('draw', self.draw_preset, key)
            content.pack_start(preview, False, False, 0)
            content.pack_start(Gtk.Label(label=title), False, False, 0)
            button.add(content);button.set_tooltip_text(description+' Words, timing and placement stay unchanged.')
            button.connect('clicked', lambda _, p=key:self.choose(p))
            grid.attach(button, index % 2, index // 2, 1, 1)
            self.preset_buttons[key] = button
        parent.pack_start(grid, False, False, 0)
        self.preview = Gtk.DrawingArea();self.preview.set_size_request(300, 66)
        self.preview.connect('draw', self.draw_preview)
        parent.pack_start(self.preview, False, False, 0)
        self.font = Gtk.FontButton()
        self.font.set_preview_text(bundled_fonts.MALAYALAM_SAMPLE)
        parent.pack_start(self.font, False, False, 0)
        self.malayalam_font = Gtk.ComboBoxText()
        self.malayalam_font.get_accessible().set_name('Malayalam Google Fonts')
        self.malayalam_font.append('', 'Malayalam Google Fonts…')
        for family, title in bundled_fonts.MALAYALAM_FONTS:
            self.malayalam_font.append(family, title)
        self.malayalam_font.set_active_id('')
        self.malayalam_font.set_tooltip_text('Bundled for offline preview and export. Choose a family, then adjust size and Bold below.')
        parent.pack_start(self.malayalam_font, False, False, 0)
        self.malayalam_font.connect('changed', self.choose_malayalam_font)
        row = Gtk.Box(spacing=12)
        self.bold = Gtk.CheckButton(label='Bold');self.italic = Gtk.CheckButton(label='Italic')
        row.pack_start(self.bold, True, True, 0);row.pack_start(self.italic, True, True, 0)
        parent.pack_start(row, False, False, 0)
        self.colors = {}
        for key, title in (('color','Text color'), ('background','Background'),
                           ('outline_color','Outline'), ('shadow_color','Shadow color')):
            picker = Gtk.ColorButton();picker.set_use_alpha(True);self.colors[key] = picker
            self.row(parent, title, picker)
        self.outline = self.number(parent, 'Outline thickness', 0, 64, .5)
        self.align = Gtk.ComboBoxText()
        for value in ('left', 'center', 'right'):self.align.append(value, value.capitalize())
        self.alignment_row = self.row(parent, self.horizontal_label, self.align)
        details = column()
        self.background_mode = Gtk.ComboBoxText()
        self.background_mode.append('box', 'Full text box')
        self.background_mode.append('text', 'Follow each line')
        self.row(details, 'Background shape', self.background_mode)
        self.background_radius = self.number(details, 'Roundness', 0, 256, 1)
        self.background_padding = self.number(details, 'Padding', 0, 128, 1)
        self.shadow_x = self.number(details, 'Shadow horizontal', -256, 256, .5)
        self.shadow_y = self.number(details, 'Shadow vertical', -256, 256, .5)
        self.shadow_blur = self.number(details, 'Shadow softness', 0, 64, .5)
        expander = Gtk.Expander(label='Background and shadow adjustments');expander.add(details)
        parent.pack_start(expander, False, False, 0)
        self.set_style(style)
        self.loading = False
        self.font.connect('font-set', self.changed)
        for widget in (self.bold, self.italic):widget.connect('toggled', self.changed)
        for widget in self.colors.values():widget.connect('color-set', self.changed)
        for widget in (self.align, self.background_mode):widget.connect('changed', self.changed)
        for widget in (self.outline, self.background_radius, self.background_padding,
                       self.shadow_x, self.shadow_y, self.shadow_blur):widget.connect('value-changed', self.changed)

    @staticmethod
    def row(parent, title, widget):
        line = Gtk.Box(spacing=8)
        line.pack_start(Gtk.Label(label=title, xalign=0), True, True, 0)
        line.pack_end(widget, False, False, 0);parent.pack_start(line, False, False, 0)
        return line

    horizontal_label = 'Alignment'

    def number(self, parent, title, low, high, step):
        spin = Gtk.SpinButton.new_with_range(low, high, step)
        spin.set_digits(1 if step < 1 else 0);spin.set_width_chars(4)
        self.row(parent, title, spin);return spin

    def set_style(self, style):
        self.loading = True
        self.font.set_font_name(f'{style.get("font_family","Sans")} {style.get("font_size",48)}')
        self.bold.set_active(style.get('bold',False));self.italic.set_active(style.get('italic',False))
        for key, picker in self.colors.items():
            picker.set_rgba(Gdk.RGBA(*visuals.rgba(style.get(key,'#00000000'))))
        self.outline.set_value(style.get('outline_width',0))
        self.align.set_active_id(style.get('align','center'))
        self.background_mode.set_active_id(style.get('background_mode','box'))
        for key, default in text_styles.effect_defaults().items():
            widget = getattr(self, key, None)
            if isinstance(widget,Gtk.SpinButton):widget.set_value(style.get(key,default))
        self.loading = False
        self.preview.queue_draw()

    def read_into(self, item):
        desc = Pango.FontDescription(self.font.get_font_name())
        item['font_family'] = desc.get_family();item['font_size'] = desc.get_size()/Pango.SCALE
        item.update(bold=self.bold.get_active(), italic=self.italic.get_active(),
                    align=self.align.get_active_id(), outline_width=self.outline.get_value(),
                    background_mode=self.background_mode.get_active_id())
        for key, picker in self.colors.items():
            color = picker.get_rgba()
            item[key] = '#'+''.join(f'{round(v*255):02x}' for v in (color.red,color.green,color.blue,color.alpha))
        for key in ('background_radius','background_padding','shadow_x','shadow_y','shadow_blur'):
            item[key] = getattr(self,key).get_value()
        return item

    def choose(self, preset):
        style = self.read_into(copy.deepcopy(self.base))
        self.set_style(self.preset_style(style, preset))
        for key, button in self.preset_buttons.items():
            context = button.get_style_context()
            context.add_class('suggested-action') if key==preset else context.remove_class('suggested-action')

    def changed(self, *_):
        if not self.loading:
            self.preview.queue_draw()
            for button in self.preset_buttons.values():button.get_style_context().remove_class('suggested-action')

    def choose_malayalam_font(self, combo):
        family = combo.get_active_id()
        if not family:return
        style = self.read_into(copy.deepcopy(self.base))
        style['font_family'] = family
        self.set_style(style)
        if not bundled_fonts.has_malayalam(self.sample):self.set_sample(bundled_fonts.MALAYALAM_SAMPLE)

    def set_sample(self, text):
        self.sample = text[:150] or 'Your words stay editable';self.preview.queue_draw()

    def paint_sample(self, widget, cr, style, text):
        width,height = widget.get_allocated_width(),widget.get_allocated_height()
        cr.set_source_rgb(.12,.22,.28);cr.paint()
        cr.set_source_rgba(.28,.48,.49,.5)
        cr.move_to(0,height);cr.line_to(width*.35,0);cr.line_to(width*.7,height);cr.fill()
        # Fixed preview font size keeps font-picker changes legible in this small
        # sample; effect widths are scaled by the same factor as the real glyphs.
        scale = 22/max(1,style.get('font_size',48))
        for key in ('outline_width','shadow_x','shadow_y','shadow_blur',
                    'background_radius','background_padding','highlight_radius','highlight_padding'):
            style[key] = style.get(key,0)*scale
        style.update(kind='text',text=text,font_size=22,x=.5,y=.5,width=.96,height=.92,
                     rotation=0,opacity=1)
        if style.get('word_highlight'):
            step = getattr(self, 'sample_step', 0) if widget is self.preview else 1
            style.update(_text_effect='highlight', _text_step=step % max(1, len(text.split())))
        visuals._paint(cr,{'width':width,'height':height},style,(0,0,width,height))
        return False

    def draw_preset(self, widget, cr, key):
        from . import model
        style = self.preset_style(model.text_style(), key)
        self.paint_sample(widget, cr, style, 'One two' if style.get('word_highlight') else 'Aa')
        return False

    preset_style = staticmethod(text_styles.apply_preset)

    def draw_preview(self, widget, cr):
        self.paint_sample(widget,cr,self.read_into(copy.deepcopy(self.base)),self.sample)
        return False


class CaptionStyleEditor(TextStyleEditor):
    """Caption appearance, placement and persistent named presets in one editor."""
    presets = tuple((key, 'Highlight', 'Highlight each word as it is spoken.') if key == 'highlight'
                    else (key, title, description) for key, title, description in text_styles.PRESETS)
    horizontal_label = 'Horizontal alignment'

    @staticmethod
    def preset_style(style, preset):
        if preset == 'highlight':
            return caption_styles.spoken_word(style)
        return dict(text_styles.apply_preset(style, preset), word_highlight=False)

    def __init__(self, parent, style, preferences):
        self.preferences = preferences
        self.sample_step = 0
        super().__init__(parent, style)
        controls = column()
        parent.pack_start(controls, False, False, 0)
        parent.reorder_child(controls, 3)
        parent.remove(self.alignment_row)
        controls.pack_start(self.alignment_row, False, False, 0)
        self.vertical = Gtk.ComboBoxText()
        for value in ('top', 'middle', 'bottom'):
            self.vertical.append(value, value.capitalize())
        self.row(controls, 'Vertical alignment', self.vertical)
        self.vertical.connect('changed', self.changed)
        self.word_highlight = Gtk.CheckButton(label='Highlight the spoken word')
        controls.pack_start(self.word_highlight, False, False, 0)
        self.word_highlight.connect('toggled', self.changed)
        hint = Gtk.Label(label='Generated captions follow speech timestamps. Imported, older or edited captions use evenly spaced timing until regenerated.', xalign=0)
        hint.set_line_wrap(True);hint.set_max_width_chars(42)
        controls.pack_start(hint, False, False, 0)
        for key, title in (('highlight_color', 'Active word background'), ('active_color', 'Active word text')):
            picker = Gtk.ColorButton();picker.set_use_alpha(True);self.colors[key] = picker
            self.row(controls, title, picker);picker.connect('color-set', self.changed)
        self.highlight_radius = self.number(controls, 'Highlight roundness', 0, 256, 1)
        self.highlight_padding = self.number(controls, 'Highlight padding', 0, 128, 1)
        for widget in (self.highlight_radius, self.highlight_padding):widget.connect('value-changed', self.changed)
        self.preview_timer = 0
        self.preview.connect('map', self.start_sample)
        self.preview.connect('unmap', self.stop_sample)
        self.saved = Gtk.ComboBoxText()
        self.saved.get_accessible().set_name('Saved caption presets')
        self.row(controls, 'Saved presets', self.saved)
        load = Gtk.Button(label='Load preset');load.connect('clicked', self.load_preset)
        controls.pack_start(load, False, False, 0)
        self.preset_name = Gtk.Entry();self.preset_name.set_placeholder_text('Preset name');self.preset_name.set_max_length(80)
        controls.pack_start(self.preset_name, False, False, 0)
        save = Gtk.Button(label='Save as preset');save.connect('clicked', self.save_preset)
        controls.pack_start(save, False, False, 0)
        self.preset_message = Gtk.Label(label='Presets include style and placement, and are available in every project. Saving the same name updates it.', xalign=0)
        self.preset_message.set_line_wrap(True);self.preset_message.set_max_width_chars(42)
        controls.pack_start(self.preset_message, False, False, 0)
        self.refresh_presets()
        self.set_style(style)

    def set_style(self, style):
        style = {**caption_styles.defaults(), **style}
        self.base = copy.deepcopy(style)
        super().set_style(style)
        if not hasattr(self, 'vertical'):return
        self.loading = True
        self.word_highlight.set_active(style['word_highlight'])
        for key in ('highlight_radius', 'highlight_padding'):getattr(self,key).set_value(style[key])
        for combo, current, anchors in ((self.align, style['x'], self.horizontal_anchors(style)),
                                        (self.vertical, style['y'], self.vertical_anchors(style))):
            # Preserve an existing free-positioned preset until this axis is changed.
            choices = list(anchors)
            if len(combo.get_model()) > len(choices):
                combo.remove(len(choices))
            selected = style['align'] if combo is self.align else min(choices, key=lambda key: abs(anchors[key]-current))
            if abs(anchors[selected]-current) > 1e-6:
                combo.append('saved', 'Saved position')
                selected = 'saved'
            combo.set_active_id(selected)
        self.loading = False
        self.preview.queue_draw()

    def read_into(self, item):
        super().read_into(item)
        if hasattr(self, 'vertical'):
            item['animation'] = copy.deepcopy(self.base.get('animation', {}))
            item['word_highlight'] = self.word_highlight.get_active()
            for key in ('highlight_radius', 'highlight_padding'):item[key] = getattr(self,key).get_value()
            item.update(width=self.base['width'], height=self.base['height'])
            horizontal = self.align.get_active_id()
            item['align'] = self.base['align'] if horizontal == 'saved' else horizontal
            item['x'] = self.horizontal_anchors(item).get(horizontal, self.base['x'])
            item['y'] = self.vertical_anchors(item).get(self.vertical.get_active_id(), self.base['y'])
        return item

    @staticmethod
    def horizontal_anchors(style):
        inset = min(.5, style['width']/2+.05)
        return dict(left=inset, center=.5, right=1-inset)

    @staticmethod
    def vertical_anchors(style):
        inset = min(.5, style['height']/2+.045)
        return dict(top=inset, middle=.5, bottom=1-inset)

    def start_sample(self, *_):
        if not self.preview_timer:
            self.preview_timer = GLib.timeout_add(450, self.advance_sample)

    def stop_sample(self, *_):
        if self.preview_timer:
            GLib.source_remove(self.preview_timer)
            self.preview_timer = 0

    def advance_sample(self):
        if self.word_highlight.get_active():
            self.sample_step += 1
            self.preview.queue_draw()
        return True

    def refresh_presets(self, selected=None):
        from .caption_styles import saved_presets
        self.saved.remove_all()
        for name in saved_presets(self.preferences):self.saved.append(name, name)
        if selected:self.saved.set_active_id(selected)

    def load_preset(self, *_):
        from .caption_styles import saved_presets
        name = self.saved.get_active_id()
        style = saved_presets(self.preferences).get(name)
        if style:
            self.set_style(style);self.preset_name.set_text(name)
            self.preset_message.set_text('Loaded '+name+'. Apply to use it in this project.')

    def save_preset(self, *_):
        from .caption_styles import save_preset
        try:
            name = save_preset(self.preferences, self.preset_name.get_text(), self.read_into(copy.deepcopy(self.base)))
        except (ValueError, OSError) as error:
            self.preset_message.set_text(str(error));return
        self.refresh_presets(name)
        self.preset_message.set_text('Saved '+name+' with its style and placement.')
